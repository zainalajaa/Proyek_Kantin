
<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 md:px-6 py-4 space-y-4">

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 text-sm px-4 py-2 rounded-lg">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-700 text-sm px-4 py-2 rounded-lg">
            <ul class="list-disc ml-4">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($err); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="flex items-center justify-between">
        <h2 class="text-lg font-semibold text-gray-800">Data Produk</h2>

        <a href="<?php echo e(route('admin.produk.tambah')); ?>"
           class="px-4 py-2 rounded-lg bg-[#009688] text-white text-sm hover:bg-[#00796B]">
            + Tambah Produk
        </a>
    </div>

    
    <?php echo $__env->make('produk.tabel', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Proyek_Kantin\resources\views/produk/lihat.blade.php ENDPATH**/ ?>