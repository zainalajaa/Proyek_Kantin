

<?php $__env->startSection('title', 'Penjualan'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-sm rounded-lg p-6">

    <!-- HEADER + FILTER -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">

        <div>
            <h1 class="text-xl font-semibold text-gray-800">Penjualan Produk</h1>
            <p class="text-sm text-gray-500">
                Total: <strong><?php echo e($penjualan->total()); ?></strong> transaksi
            </p>
        </div>

        <!-- FILTER DROPDOWN -->
        <form method="GET" action="<?php echo e(route('admin.penjualan.index')); ?>">
            <select name="filter"
                onchange="this.form.submit()"
                class="text-sm border-gray-300 rounded-md shadow-sm focus:ring-emerald-500 focus:border-emerald-500">

                <option value="">Semua Periode</option>
                <option value="harian" <?php echo e(request('filter') == 'harian' ? 'selected' : ''); ?>>
                    Harian
                </option>
                <option value="mingguan" <?php echo e(request('filter') == 'mingguan' ? 'selected' : ''); ?>>
                    Mingguan
                </option>
                <option value="bulanan" <?php echo e(request('filter') == 'bulanan' ? 'selected' : ''); ?>>
                    Bulanan
                </option>
            </select>
        </form>

    </div>

    <!-- TABEL -->
    <div class="overflow-x-auto">
        <table class="min-w-full border-separate border-spacing-y-2 text-sm">
            <thead>
                <tr class="text-xs uppercase tracking-wider text-gray-500">
                    <th class="px-4 py-3 text-left">No</th>
                    <th class="px-4 py-3 text-left">Waktu</th>
                    <th class="px-4 py-3 text-left">Metode</th>
                    <th class="px-4 py-3 text-right">Total</th>
                    <th class="px-4 py-3 text-right">Dibayar</th>
                    <th class="px-4 py-3 text-left">Paid At</th>
                    <th class="px-4 py-3 text-center">Status</th>
                    <th class="px-4 py-3 text-center">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="bg-white shadow-sm hover:shadow-md transition rounded-lg">

                    <td class="px-4 py-4">
                        <?php echo e($penjualan->firstItem() + $loop->index); ?>

                    </td>

                    <td class="px-4 py-4 text-gray-600 whitespace-nowrap">
                        <?php echo e(\Carbon\Carbon::parse($p->waktu)->format('d M Y, H:i')); ?>

                    </td>

                    <td class="px-4 py-4 capitalize font-medium">
                        <?php echo e($p->metode_pembayaran ?? '-'); ?>

                    </td>

                    <td class="px-4 py-4 text-right font-semibold">
                        Rp <?php echo e(number_format($p->total_harga, 0, ',', '.')); ?>

                    </td>

                    <td class="px-4 py-4 text-right text-gray-700">
                        <?php echo e($p->paid_amount 
                            ? 'Rp ' . number_format($p->paid_amount, 0, ',', '.') 
                            : '-'); ?>

                    </td>

                    <td class="px-4 py-4 text-gray-500 whitespace-nowrap">
                        <?php echo e($p->paid_at 
                            ? \Carbon\Carbon::parse($p->paid_at)->format('d M Y, H:i') 
                            : '-'); ?>

                    </td>

                    <td class="px-4 py-4 text-center">
                        <?php if($p->status === 'sukses'): ?>
                            <span class="px-3 py-1 text-xs font-medium rounded-full bg-emerald-100 text-emerald-700">
                                Sukses
                            </span>

                        <?php elseif($p->status === 'pending_qris'): ?>
                            <span class="px-3 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-700">
                                QRIS Pending
                            </span>

                        <?php else: ?>
                            <span class="px-3 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-700">
                                <?php echo e(ucfirst($p->status)); ?>

                            </span>
                        <?php endif; ?>
                    </td>

                    <td class="px-4 py-4 text-center">
                        <a href="<?php echo e(route('admin.penjualan.show', $p->id)); ?>"
                           class="inline-block px-4 py-1.5 text-xs font-medium rounded-md bg-blue-600 text-white hover:bg-blue-500 transition">
                            Detail
                        </a>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="px-4 py-6 text-center text-gray-500">
                        Belum ada transaksi.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- PAGINATION -->
    <div class="mt-6">
        <?php echo e($penjualan->onEachSide(1)->links('pagination::simple-tailwind')); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Proyek_Kantin\resources\views/penjualan/tabel.blade.php ENDPATH**/ ?>