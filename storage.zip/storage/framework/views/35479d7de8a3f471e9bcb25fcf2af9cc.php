<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', 'Kantin Kejujuran ULP PLN Banjarbaru'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>

    <script src="https://kit.fontawesome.com/a2d9d5e9b2.js" crossorigin="anonymous" defer></script>
</head>
<body class="bg-[#F9FAFB] text-[#1E293B] min-h-screen flex flex-col">

    
    <nav class="bg-[#009DAE] text-white shadow-lg sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center py-4">
                
                <div class="flex items-center gap-3">
                    <?php
                        $logoPath = 'storage/images/logo-kj.png';
                    ?>

                    <?php if(file_exists(public_path($logoPath))): ?>
                        <img src="<?php echo e(asset($logoPath)); ?>"
                             alt="Logo Kantin"
                             class="h-10 w-10 object-contain bg-white p-1 rounded-full shadow-md">
                    <?php else: ?>
                        
                        <div class="h-10 w-10 rounded-full bg-white flex items-center justify-center shadow-md text-[#009DAE] font-bold">
                            KK
                        </div>
                    <?php endif; ?>

                    <div class="leading-tight">
                        <a href="<?php echo e(route('publik.index')); ?>" class="block">
                            <h1 class="text-lg md:text-xl font-bold tracking-wide">Kantin Kejujuran</h1>
                            <p class="text-xs md:text-sm opacity-90">ULP PLN Banjarbaru</p>
                        </a>
                    </div>
                </div>

                
                <div class="flex items-center">
                    <a href="<?php echo e(route('cart.index')); ?>"
                    class="relative inline-flex items-center justify-center h-10 w-10 rounded-full 
                            bg-white/10 hover:bg-white/20 transition">

                        
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" 
                            fill="currentColor" class="h-5 w-5 text-white">
                            <path d="M2.25 2.25a.75.75 0 000 1.5h1.386c.17 0 .318.114.362.278l2.558 9.593A2.25 2.25 0 008.75 15h9.5a2.25 2.25 0 002.143-1.57l1.6-5A.75.75 0 0021.25 7.5h-14a.75.75 0 01-.727-.568L5.04 3.028A1.875 1.875 0 003.636 2.25H2.25z" />
                            <path d="M8.25 18a1.5 1.5 0 100 3 1.5 1.5 0 000-3zm8.25 0a1.5 1.5 0 100 3 1.5 1.5 0 000-3z" />
                        </svg>

                        
                        <?php
                            $cartCount = session('cart_count', 0);
                        ?>

                        <?php if($cartCount > 0): ?>
                            <span class="absolute -top-1 -right-1 
                                        h-5 min-w-[1.25rem] px-1
                                        flex items-center justify-center
                                        rounded-full bg-[#FDC500]
                                        text-[10px] font-bold text-[#1E293B]">
                                <?php echo e($cartCount); ?>

                            </span>
                        <?php endif; ?>
                    </a>
                </div>

            </div>
        </div>
    </nav>

    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6 w-full">

        <?php if(session('success')): ?>
            <div id="flash-success"
                class="flash-message mb-6 flex items-center gap-4 
                    rounded-2xl border border-emerald-200 
                    bg-emerald-50 text-emerald-700 
                    px-5 py-4 shadow-sm transition-all duration-500">

                <div class="flex items-center justify-center 
                            h-9 w-9 rounded-xl 
                            bg-emerald-100 text-emerald-600 font-bold">
                    ✓
                </div>

                <div class="flex-1 text-sm font-semibold">
                    <?php echo e(session('success')); ?>

                </div>

                <button onclick="closeFlash('flash-success')"
                    class="text-emerald-500 hover:text-emerald-700 text-sm font-medium transition">
                    ✕
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div id="flash-error"
                class="flash-message mb-6 flex items-center gap-4 
                    rounded-2xl border border-red-200 
                    bg-red-50 text-red-700 
                    px-5 py-4 shadow-sm transition-all duration-500">

                <div class="flex items-center justify-center 
                            h-9 w-9 rounded-xl 
                            bg-red-100 text-red-600 font-bold">
                    ⚠
                </div>

                <div class="flex-1 text-sm font-semibold">
                    <?php echo e(session('error')); ?>

                </div>

                <button onclick="closeFlash('flash-error')"
                    class="text-red-500 hover:text-red-700 text-sm font-medium transition">
                    ✕
                </button>
            </div>
        <?php endif; ?>
    </div>

    
    <main class="flex-1">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    
    <footer class="bg-[#009DAE] text-white text-center py-6 mt-6">
        <p class="text-sm">&copy; <?php echo e(date('Y')); ?> Kantin Kejujuran ULP PLN Banjarbaru. Semua Hak Dilindungi.</p>
    </footer>

    <?php echo $__env->yieldPushContent('scripts'); ?>

    <script>
        function closeFlash(id) {
            const el = document.getElementById(id);
            if (!el) return;

            el.style.opacity = '0';
            setTimeout(() => el.remove(), 500);
        }

        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(el => {
                el.style.opacity = '0';
                setTimeout(() => el.remove(), 500);
            });
        }, 3000);
    </script>

</body>
</html>
<?php /**PATH D:\laragon\www\Proyek_Kantin\resources\views/layouts/publik.blade.php ENDPATH**/ ?>