<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\laragon\www\Proyek_Kantin\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>