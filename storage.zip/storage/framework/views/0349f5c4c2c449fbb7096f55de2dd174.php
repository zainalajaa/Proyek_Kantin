

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="px-6 py-8 space-y-10">

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-7">

        
        <div class="relative overflow-hidden rounded-2xl p-6 text-white shadow-xl
                    bg-gradient-to-br from-blue-500 to-blue-700
                    transition duration-300 hover:scale-105">

            <div class="flex justify-between items-start">
                <div>
                    <p class="text-sm opacity-80">Total Produk</p>
                    <h2 class="text-4xl font-bold mt-2">
                        <?php echo e($totalProduk); ?>

                    </h2>
                </div>
                <div class="text-4xl opacity-80">
                    🧺
                </div>
            </div>

            <div class="absolute -right-10 -bottom-10 w-40 h-40 bg-white opacity-10 rounded-full"></div>
        </div>

        
        <div class="relative overflow-hidden rounded-2xl p-6 text-white shadow-xl
                    bg-gradient-to-br from-yellow-400 to-orange-500
                    transition duration-300 hover:scale-105">

            <div class="flex justify-between items-start">
                <div>
                    <p class="text-sm opacity-80">Total Makanan</p>
                    <h2 class="text-4xl font-bold mt-2">
                        <?php echo e($totalMakanan); ?>

                    </h2>
                </div>
                <div class="text-4xl opacity-80">
                    🍜
                </div>
            </div>

            <div class="absolute -right-10 -bottom-10 w-40 h-40 bg-white opacity-10 rounded-full"></div>
        </div>


        
        <div class="relative overflow-hidden rounded-2xl p-6 text-white shadow-xl
                    bg-gradient-to-br from-emerald-400 to-teal-600
                    transition duration-300 hover:scale-105">

            <div class="flex justify-between items-start">
                <div>
                    <p class="text-sm opacity-80">Total Minuman</p>
                    <h2 class="text-4xl font-bold mt-2">
                        <?php echo e($totalMinuman); ?>

                    </h2>
                </div>
                <div class="text-4xl opacity-80">
                    🥤
                </div>
            </div>

            <div class="absolute -right-10 -bottom-10 w-40 h-40 bg-white opacity-10 rounded-full"></div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Proyek_Kantin\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>