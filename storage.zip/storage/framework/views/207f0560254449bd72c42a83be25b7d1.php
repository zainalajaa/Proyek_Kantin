

<?php $__env->startSection('title', 'Detail Penjualan'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow-sm rounded-lg p-6">

    <!-- HEADER -->
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-xl font-semibold text-gray-800">Detail Penjualan</h1>
            <p class="text-sm text-gray-500">
                Informasi lengkap transaksi
            </p>
        </div>

        <a href="<?php echo e(route('admin.penjualan.index')); ?>"
           class="px-4 py-2 text-sm font-medium rounded-md bg-gray-300 text-gray-700 hover:bg-gray-400 transition">
            Kembali
        </a>
    </div>

    <!-- INFORMASI TRANSAKSI -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 text-sm">

        <div class="space-y-3">
            <div>
                <p class="text-gray-500">Nomor Transaksi</p>
                <p class="font-medium"><?php echo e($penjualan->id); ?></p>
            </div>

            <div>
                <p class="text-gray-500">Waktu Transaksi</p>
                <p class="font-medium">
                    <?php echo e(\Carbon\Carbon::parse($penjualan->waktu)->format('d M Y, H:i')); ?>

                </p>
            </div>

            <div>
                <p class="text-gray-500">Metode Pembayaran</p>
                <p class="font-medium capitalize">
                    <?php echo e($penjualan->metode_pembayaran); ?>

                </p>
            </div>
        </div>

        <div class="space-y-3">
            <div>
                <p class="text-gray-500">Jumlah Dibayar</p>
                <p class="font-medium">
                    <?php echo e($penjualan->paid_amount 
                        ? 'Rp ' . number_format($penjualan->paid_amount, 0, ',', '.') 
                        : '-'); ?>

                </p>
            </div>

            <div>
                <p class="text-gray-500">Waktu Pembayaran</p>
                <p class="font-medium">
                    <?php echo e($penjualan->paid_at 
                        ? \Carbon\Carbon::parse($penjualan->paid_at)->format('d M Y, H:i') 
                        : '-'); ?>

                </p>
            </div>

            <div>
                <p class="text-gray-500">Status Transaksi</p>

                <?php if($penjualan->status === 'sukses'): ?>
                    <span class="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-emerald-100 text-emerald-700">
                        Sukses
                    </span>

                <?php elseif($penjualan->status === 'pending_qris'): ?>
                    <span class="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-700">
                        Menunggu Pembayaran QRIS
                    </span>

                <?php else: ?>
                    <span class="inline-flex px-3 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-700">
                        <?php echo e(ucfirst($penjualan->status)); ?>

                    </span>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <!-- DETAIL PRODUK -->
    <div>
        <h2 class="text-lg font-semibold text-gray-800 mb-4">
            Daftar Produk
        </h2>

        <div class="overflow-x-auto">
            <table class="min-w-full border-separate border-spacing-y-2 text-sm">
                <thead>
                    <tr class="text-xs uppercase tracking-wider text-gray-500">
                        <th class="px-4 py-3 text-left">Nama Produk</th>
                        <th class="px-4 py-3 text-right">Harga Satuan</th>
                        <th class="px-4 py-3 text-center">Jumlah</th>
                        <th class="px-4 py-3 text-right">Subtotal</th>
                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $penjualan->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-white shadow-sm hover:shadow-md transition rounded-lg">
                            <td class="px-4 py-4 font-medium">
                                <?php echo e($d->nama_produk); ?>

                            </td>

                            <td class="px-4 py-4 text-right">
                                Rp <?php echo e(number_format($d->harga_satuan, 0, ',', '.')); ?>

                            </td>

                            <td class="px-4 py-4 text-center">
                                <?php echo e($d->jumlah); ?>

                            </td>

                            <td class="px-4 py-4 text-right font-semibold">
                                Rp <?php echo e(number_format($d->subtotal, 0, ',', '.')); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- TOTAL DI PINDAH KE SINI -->
        <div class="mt-6 flex justify-end">
            <div class="bg-gray-50 px-6 py-4 rounded-lg shadow-sm text-right">
                <p class="text-sm text-gray-500">Total Pembayaran</p>
                <p class="text-xl font-bold text-gray-800">
                    Rp <?php echo e(number_format($penjualan->total_harga, 0, ',', '.')); ?>

                </p>
            </div>
        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\Proyek_Kantin\resources\views/penjualan/detail.blade.php ENDPATH**/ ?>